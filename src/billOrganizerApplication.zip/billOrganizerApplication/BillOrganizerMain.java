package billOrganizerApplication;

public class BillOrganizerMain {
	public static void main(String[] args) {
		BillOrganizerFrame frame = new BillOrganizerFrame();
		frame.setVisible(true);
	}
}
