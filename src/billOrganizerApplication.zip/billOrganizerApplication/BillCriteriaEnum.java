package billOrganizerApplication;

public enum BillCriteriaEnum {
	BILLDUEDATE, BILLAMOUNT, BILLTYPE;
}
