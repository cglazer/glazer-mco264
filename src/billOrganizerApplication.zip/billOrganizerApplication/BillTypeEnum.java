package billOrganizerApplication;

public enum BillTypeEnum {
	CLOTHING, EDUCATION, FOOD, GROCERIES, PHONE, TRAVEL, UTILITIES;
}
