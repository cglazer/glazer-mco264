package binaryTree;

public class binaryTreeMain<T extends Comparable<T>> {

	public static void main(String[] args) {
		BinaryTreeFrame frame = new BinaryTreeFrame();
		frame.setVisible(true);
	}
}
