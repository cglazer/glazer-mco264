package countBlobs;

public class InvalidGridException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidGridException() {
		super();
	}
}
