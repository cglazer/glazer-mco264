package schoolApplication;

public enum Gender { FEMALE, MALE

}
