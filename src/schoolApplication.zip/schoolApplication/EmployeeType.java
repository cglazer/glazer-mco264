package schoolApplication;

public enum EmployeeType {
	ACCOUNTANT, CHAIRPERSON, CLERK, DEAN, PROFESSOR, INSTRUCTOR, MAINTENANCE, SECRETARY
}
