package ticTacToe;

public class AlreadyFilledException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public AlreadyFilledException(){
	super();
}
}
